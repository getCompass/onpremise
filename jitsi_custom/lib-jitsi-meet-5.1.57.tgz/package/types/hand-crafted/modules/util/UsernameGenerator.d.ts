export function generateUsername(): string;
